// API de chuck norris

$(document).ready(function () {
    
    var chiste = "";
    fetch('https://studio-ghibli-films-api.herokuapp.com/')
    .then((response) => response.json())
    .then((json) => console.log(json));
    
});