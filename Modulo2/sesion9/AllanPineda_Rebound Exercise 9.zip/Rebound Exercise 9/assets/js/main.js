// funciones 

function mostrarT2() {
    document.getElementById('text2').style.display = "block";
}

function ocultarT2() {
    document.getElementById('text2').style.display = "none";
}

function agrandarImg() {
    document.getElementById('img').style.width = "100%";
}

function encogerImg() {
    document.getElementById('img').style.width = "20%"
}

function agrandarLetra() {
    document.getElementById('caja3').style.fontSize = "xx-large"
}

function encogerLetra() {
    document.getElementById('caja3').style.fontSize = "xx-small"
}